#ifndef LAB8_H
#include<iostream>
class vector
{
	int sz=0;
	int* c=NULL;
	char* elem=NULL;
public:
	vector(int s) :sz(s), elem(new char[s])
	{
		for (int i = 0; i < s; i++)
		{
			elem[i] = '-';
		}
	}
	~vector() { delete[] elem; }
	int get(int n)
	{
		return elem[n];
	}
	void set(int n, char v)
	{
		elem[n] = v;
	}
	void print()
	{
		for(int i=0;i<5;i++)
		std::cout<<elem[i];
	}
    int size() const { return sz; }
};
#endif // !LAB8_H
