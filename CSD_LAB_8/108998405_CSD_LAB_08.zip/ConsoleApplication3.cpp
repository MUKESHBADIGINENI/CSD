#include<iostream>
#include "Lab8.h"
#include<string>
#include<sstream>
using namespace std;
int main()
{
	vector v(5);
	v.print(); // this should display -, -, -, -,
	for (int i = 0; i < v.size(); ++i)
	{
		string s;
		ostringstream ss;
		ss << i;
		cout << ss.str() << " ,";
	}
}