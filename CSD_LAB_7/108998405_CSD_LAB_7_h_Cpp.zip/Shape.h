#ifndef SHAPE_H
#define SHAPE_H

class Shape {	// This is the base class!

public:
	Shape() {};
	float get_area();
	float area, perimeter;
};
#endif 